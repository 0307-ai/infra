import boto3
import json
import logging
import os
import urllib.request
from urllib.error import HTTPError, URLError
from base64 import b64encode
import time

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    arn = event['SecretId']
    token = event['ClientRequestToken']
    step = event['Step']
    print(event)
    # Setup the client
    service_client = boto3.client('secretsmanager', endpoint_url=os.environ['SECRETS_MANAGER_ENDPOINT'])

    # Make sure the version is staged correctly
    metadata = service_client.describe_secret(SecretId=arn)
    if "RotationEnabled" in metadata and not metadata['RotationEnabled']:
        logger.error("Secret %s is not enabled for rotation" % arn)
        raise ValueError("Secret %s is not enabled for rotation" % arn)
    versions = metadata['VersionIdsToStages']
    if token not in versions:
        logger.error("Secret version %s has no stage for rotation of secret %s." % (token, arn))
        raise ValueError("Secret version %s has no stage for rotation of secret %s." % (token, arn))
    if "AWSCURRENT" in versions[token]:
        logger.info("Secret version %s already set as AWSCURRENT for secret %s." % (token, arn))
        return
    elif "AWSPENDING" not in versions[token]:
        logger.error("Secret version %s not set as AWSPENDING for rotation of secret %s." % (token, arn))
        raise ValueError("Secret version %s not set as AWSPENDING for rotation of secret %s." % (token, arn))

    # Call the appropriate step
    if step == "createSecret":
        create_secret(service_client, arn, token)
    elif step == "setSecret":
        set_secret(service_client, arn, token)

    elif step == "testSecret":
        test_secret(service_client, arn, token)

    elif step == "finishSecret":
        finish_secret(service_client, arn, token)

    else:
        logger.error("lambda_handler: Invalid step parameter %s for secret %s" % (step, arn))
        raise ValueError("Invalid step parameter %s for secret %s" % (step, arn))


def create_secret(service_client, arn, token):
    # Make sure the current secret exists
    current_dict = get_secret_dict(service_client, arn, "AWSCURRENT")

    # Now try to get the secret version, if that fails, put a new secret
    try:
        get_secret_dict(service_client, arn, "AWSPENDING", token)
        logger.info("createSecret: Successfully retrieved secret for %s." % arn)
    except service_client.exceptions.ResourceNotFoundException:
        # Generate a random password
        passwd = service_client.get_random_password(
            PasswordLength=20
        )
        current_dict['password'] = passwd['RandomPassword']

        # Put the secret
        service_client.put_secret_value(SecretId=arn, ClientRequestToken=token, SecretString=json.dumps(current_dict), VersionStages=['AWSPENDING'])
        logger.info("createSecret: Successfully put secret for ARN %s and version %s." % (arn, token))


def set_secret(service_client, arn, token):
    current_dict = get_secret_dict(service_client, arn, "AWSCURRENT")
    pending_dict = get_secret_dict(service_client, arn, "AWSPENDING", token)
    opensearch_client = boto3.client('opensearch', endpoint_url=os.environ['OPENSEARCH_ENDPOINT'])

    # Update the OpenSearch domain configuration with the new password
    try:
        response = opensearch_client.update_domain_config(
            DomainName=pending_dict["domain_name"],
            AdvancedSecurityOptions={
                'Enabled': True,
                'MasterUserOptions': {
                    'MasterUserName' : pending_dict["username"],
                    'MasterUserPassword': pending_dict["password"]
                }
            }
        )
        # Print the response for debugging purposes
        logger.info("set_secret: OpenSearch domain configuration updated:", response)
    except Exception as e:
        logger.info("set_secret: Error updating OpenSearch domain configuration:", e)


def test_secret(service_client, arn, token):
    pending_dict = get_secret_dict(service_client, arn, "AWSPENDING", token)
    url = f'https://{pending_dict["domain_endpoint"]}:443'
    print(url)
    request = urllib.request.Request(url)
    username= pending_dict["username"]
    password= pending_dict["password"]
    credentials = f"{username}:{password}"
    encoded_credentials = b64encode(credentials.encode()).decode("ascii")
    request.add_header("Authorization", f"Basic {encoded_credentials}")
    
    try:
        print(urllib.request.urlopen(request))
        with urllib.request.urlopen(request) as response:
            if response.getcode() == 200:
                logger.info("test_secret: Domain is accessible")
                return "Domain is accessible"
            else:
                logger.info("test_secret: Domain is not accessible")
                return f"Domain is not accessible. Status code: {response.getcode()}"
    except HTTPError as e:
        logger.info(f"test_secret:HTTP Error: {e.code}")
        return f"HTTP Error: {e.code}"
    except URLError as e:
        logger.info(f"test_secret:URL Error: {e.reason}")
        return f"URL Error: {e.reason}"

def finish_secret(service_client, arn, token):
    # First describe the secret to get the current version
    metadata = service_client.describe_secret(SecretId=arn)
    current_version = None
    for version in metadata["VersionIdsToStages"]:
        if "AWSCURRENT" in metadata["VersionIdsToStages"][version]:
            if version == token:
                # The correct version is already marked as current, return
                logger.info("finishSecret: Version %s already marked as AWSCURRENT for %s" % (version, arn))
                return
            current_version = version
            break

    # Finalize by staging the secret version current
    service_client.update_secret_version_stage(SecretId=arn, VersionStage="AWSCURRENT", MoveToVersionId=token, RemoveFromVersionId=current_version)
    logger.info("finishSecret: Successfully set AWSCURRENT stage to version %s for secret %s." % (token, arn))

def get_secret_dict(service_client, arn, stage, token=None):
    required_fields = ['domain_endpoint', 'domain_name', 'username', "password"]

    # Only do VersionId validation against the stage if a token is passed in
    if token:
        secret = service_client.get_secret_value(SecretId=arn, VersionId=token, VersionStage=stage)
    else:
        secret = service_client.get_secret_value(SecretId=arn, VersionStage=stage)
    plaintext = secret['SecretString']
    secret_dict = json.loads(plaintext)

    for field in required_fields:
        if field not in secret_dict:
            raise KeyError("%s key is missing from secret JSON" % field)

    # Parse and return the secret JSON string
    return secret_dict